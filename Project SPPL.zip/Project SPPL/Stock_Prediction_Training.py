# -*- coding: utf-8 -*-
"""
Created on Mon Apr  3 14:58:48 2023

@author: Siva Shankar
"""
# Importing the necessary libraries
import pandas as pd
import numpy as np
from keras.models import Sequential
from keras.layers import Dense, LSTM
from sklearn.model_selection import train_test_split

# Reading the financial data from a CSV file
data = pd.read_csv(r"C:\Users\venka\OneDrive\Desktop\Project SPPL\Datadet.csv")

# print(set(data['stock']))
# Selecting the input features (open, high, low, volume) and the target variable (adj_close)
x = data[["open", "high", "low", "volume"]]
y = data["adj_close"]

# Converting the input features and target variable to numpy arrays
x = x.to_numpy()
y = y.to_numpy()

# Reshaping the target variable to have a single column
y = y.reshape(-1, 1)

# Splitting the data into training and testing sets
xtrain, xtest, ytrain, ytest = train_test_split(x, y, test_size=0.2, random_state=52)

# Building the LSTM model
model = Sequential()
model.add(LSTM(128, return_sequences=True, input_shape= (xtrain.shape[1], 1)))
model.add(LSTM(64, return_sequences=False))
model.add(Dense(25))
model.add(Dense(1))
model.summary()

# Compiling and fitting the model to the training data
model.compile(optimizer='adam', loss='mean_squared_error')
model.fit(xtrain, ytrain, batch_size=1, epochs=30)

# Making predictions using the trained model
l =list(map(int, input().split()))
features = np.array([l])
print(features)
prediction = model.predict(features)
print(prediction)


